
const fs = require('fs').promises;
const { listenerCount } = require('process');


function findMax(intArr) {
    let currentMax = intArr[0];
    for (const currInt of intArr) {
        if(currInt>currentMax) {
            currentMax=currInt;
        }
    }
    return currentMax;
}

function isPyramid(pyramidLevels) {
    let lenCounter = 1;
    let ifPyramid = false ;
    for (const pyramidLevel of pyramidLevels) {
        
        if(pyramidLevel.length === lenCounter) {
            ifPyramid = true ;
        }
        else {
            ifPyramid=false ;
            break;
        }
        lenCounter++ ;
    }
    return ifPyramid ;
}

function isPrime(number) { // ofc not an optimized way, in a real-case scenario i would use a  optimized one.
    
    for (let index = 2; index < number; index++) {
        if(number%index ===  0) {
            return false ;
        }
    }
    return true ;
}

function createPyramidArr(pyramidLevels) {
    let pyramidArr = [] ;
    
    for (let index = 0; index < pyramidLevels.length; index++) {
        if(index==0) {
            pyramidArr.push(pyramidLevels[index]);
        }
       
        else {
            pyramidArr.push(pyramidLevels[index].filter(curr=>!isPrime(curr)).map((value)=>value));
        }
        
    }
    return pyramidArr;

}

  async function readSampleFile() {
    try {
        let response = await fs.readFile('sample.txt', 'utf8');
    return response.split("\r\n").map((value)=>[...value.split(" ").map((value)=>parseInt(value))]);
    } catch (error) {
        console.log("File could not be read");
    }
    
}


function findPath(pyramidArr) {
    let numbers = [] ;
    let total = 0;
    for (const pyramidLevel of pyramidArr) {
        let maxNumber = findMax(pyramidLevel);
        numbers.push(maxNumber);
        total=total+maxNumber;
    }
    return {path : numbers, sum : total};
    
}




 async function main() {
    let response =  await readSampleFile();
    
    let isItPyramid = isPyramid(response);
    let pyramid = createPyramidArr(response); // all the primes are deleted from all the pyramid levels. Excluding the first level. This way we can easily traverse through a valid path.
    if(isItPyramid) {
        console.log(findPath(pyramid));
    }
    else {
        console.log("This is not a pyramid.Enter a valid one");
    }
}

main();